package Project;


/**
 * @author lujain Abdullah
 * @author Sara Alahmari
 * @author Shaima Bashammakh
 */

    public class ShortestPathAlgorithm {
    // ---------------------------- variables ----------------------------------

    /**
     * graph variable
     */
    Graph graph;

    // ---------------------------- constructors -------------------------------

    /**
     *
     * @param graph
     */
    public ShortestPathAlgorithm(Graph graph) {
        this.graph = graph;
    }
    
    
    
}
